package igu.Gerente;

import logica.clases.Gestora;
import logica.clases.facturacion.Producto;
import logica.clases.personas.*;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Vector;


public class PantallaVerTodosEmple extends JFrame{

    public JPanel panelMain;
    private JTable tabla_empleados;
    private JButton btn_atras;
    private JButton btn_ordenDNi;
    private JToolBar toolBar_orden;
    private JButton btn_ordenAntiguedad;
    private JButton btn_ordenTrabajo;
    private DefaultTableModel modelo_tabla=new DefaultTableModel();

    public PantallaVerTodosEmple(Gestora gestora) {

        tabla_empleados.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    int index = tabla_empleados.rowAtPoint(e.getPoint());
                    if (index != -1) {

                        String dniSelec = (String) modelo_tabla.getValueAt(index, 0);
                        Empleado empleado = gestora.getGerente().getEmpleados().get(dniSelec);

                        if(empleado instanceof Usuario){

                            Usuario usu = (Usuario) empleado;

                            PantallaVerUnCajero p = new PantallaVerUnCajero(usu, gestora);

                            p.setContentPane(p.panelMain);
                            p.setLocation(300, 150);
                            p.setTitle("Vista cajero");
                            p.setSize(770, 500);
                            p.setVisible(true);
                            p.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

                            p.addWindowListener(new WindowAdapter() {
                                @Override
                                public void windowClosed(WindowEvent e) {
                                    vaciarTabla(modelo_tabla);

                                    for (Empleado emple : gestora.getGerente().getEmpleados().values())
                                        agregarFila(emple);
                                }
                            });

                        }
                        else {
                            PantallaVerUnEmpleado p = new PantallaVerUnEmpleado(empleado, gestora.getGerente());

                            p.setContentPane(p.panelMain);
                            p.setLocation(300, 150);
                            p.setTitle("Vista empleado");
                            p.setSize(770, 500);
                            p.setVisible(true);
                            p.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

                            p.addWindowListener(new WindowAdapter() {
                                @Override
                                public void windowClosed(WindowEvent e) {
                                    vaciarTabla(modelo_tabla);

                                    for (Empleado emple : gestora.getGerente().getEmpleados().values())
                                        agregarFila(emple);
                                }
                            });
                        }
                    }
                }
            }
        });

        toolBar_orden.setFloatable(false);

        modelo_tabla = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                // Hacer que todas las celdas no sean editables
                return false;
            }
        };

        modelo_tabla.addColumn("DNI");
        modelo_tabla.addColumn("Nombre completo");
        modelo_tabla.addColumn("Sueldo");
        modelo_tabla.addColumn("Cargo");

        tabla_empleados.setModel(modelo_tabla);

        tabla_empleados.getTableHeader().setReorderingAllowed(false);

        for (Empleado e : gestora.getGerente().getEmpleados().values()) {
            agregarFila(e);
        }

        btn_atras.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });

        btn_ordenDNi.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                vaciarTabla(modelo_tabla);
                for (Empleado em : gestora.getGerente().retornarArrayEmpleadoOrdenadoXdni())
                   agregarFila(em);
            }
        });
        btn_ordenTrabajo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                vaciarTabla(modelo_tabla);
                for (Object em : gestora.getGerente().arrayListOrdenadoPorCargo())
                    agregarFila((Empleado) em);
            }
        });
        btn_ordenAntiguedad.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                vaciarTabla(modelo_tabla);
                for (Object em : gestora.getGerente().arrayListOrdenarPorFechaDeIngreso())
                    agregarFila((Empleado) em);

            }
        });
    }

    public void agregarFila(Empleado e){
        Vector<Object> fila = new Vector<>();
        fila.add(e.getDni());
        fila.add(e.getNombre() + " " + e.getApellido());
        fila.add(e.getSueldo());
        fila.add(e.getCargo());
        modelo_tabla.addRow(fila);
    }

    public void vaciarTabla(DefaultTableModel model) {
        while (model.getRowCount() > 0) {
            model.removeRow(0);
        }
    }

}
