package igu.Gerente;

import igu.Admin.PantallaConfigInfoPersonalAdmin;
import igu.Cajero.PantallaAllRemitos;
import logica.clases.Gestora;
import logica.clases.personas.Empleado;
import logica.clases.personas.Usuario;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PantallaPrincipalGerente extends JFrame{
    public JPanel panelMain;
    private JLabel icon;
    private JToolBar toolBar;
    private JButton btn_verTodoEmple;
    private JButton btn_verUnEmple;
    private JButton btn_contratarEmple;
    private JButton btn_atras;
    private JButton btn_verAllRemitos;
    private JLabel lbl_nombre;
    private JLabel lbl_apellido;
    private JLabel lbl_cargo;
    private JButton btn_config;

    public PantallaPrincipalGerente(Gestora gestora) {

        toolBar.setFloatable(false);
        lbl_nombre.setText("Nombre:   " + gestora.getGerente().getNombre());
        lbl_apellido.setText("Apellido:   " + gestora.getGerente().getApellido());
        lbl_cargo.setText("Cargo:   " + gestora.getGerente().getCargo());

        btn_verTodoEmple.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                PantallaVerTodosEmple p = new PantallaVerTodosEmple(gestora);

                p.setContentPane(p.panelMain);
                p.setLocation(390, 150);
                p.setTitle("Vista empleados");
                p.setSize(590, 500);
                p.setVisible(true);
                p.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            }
        });

        btn_verUnEmple.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String userInput = JOptionPane.showInputDialog(panelMain, "Ingrese DNI del empleado buscado:", " ", JOptionPane.QUESTION_MESSAGE);

                while (userInput != null && userInput.trim().isEmpty()) {
                    JOptionPane.showMessageDialog(panelMain, "Por favor, ingrese un DNI para hacer la búsqueda.");
                    userInput = JOptionPane.showInputDialog(panelMain, "Ingrese DNI del empleado buscado:", " ", JOptionPane.QUESTION_MESSAGE);
                }

                if (userInput != null && !userInput.trim().isEmpty()) {
                    Empleado empleado = gestora.getGerente().getEmpleados().get(userInput);

                    if (empleado != null) {
                        if (empleado instanceof Usuario) {
                            Usuario usu = (Usuario) empleado;
                            PantallaVerUnCajero p = new PantallaVerUnCajero(usu, gestora);
                            p.setContentPane(p.panelMain);
                            p.setLocation(300, 150);
                            p.setTitle("Vista empleado");
                            p.setSize(770, 500);
                            p.setVisible(true);
                            p.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                        } else {
                            PantallaVerUnEmpleado p = new PantallaVerUnEmpleado(empleado, gestora.getGerente());
                            p.setContentPane(p.panelMain);
                            p.setLocation(300, 150);
                            p.setTitle("Vista empleado");
                            p.setSize(770, 500);
                            p.setVisible(true);
                            p.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "Empleado inexistente");
                    }
                }
            }
        });

        btn_contratarEmple.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                PantallaContratarEmpleado p = new PantallaContratarEmpleado(gestora.getGerente());

                p.setContentPane(p.panelMain);
                p.setLocation(470, 150);
                p.setTitle("Vista empleado");
                p.setSize(400, 500);
                p.setVisible(true);
                p.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

            }
        });

        btn_atras.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });

        btn_verAllRemitos.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                PantallaAllRemitos p = new PantallaAllRemitos(gestora);

                p.setContentPane(p.panelMain);
                p.setLocation(430, 150);
                p.setTitle("Vista remitos");
                p.setSize(500, 500);
                p.setVisible(true);
                p.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            }
        });

        btn_config.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                PantallaConfigInfoPersonalGerente p = new PantallaConfigInfoPersonalGerente(gestora);

                p.setContentPane(p.panelMain);
                p.setLocation(300, 150);
                p.setTitle("Mi perfil");
                p.setSize(770, 500);
                p.setVisible(true);
                p.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            }
        });
    }
}
