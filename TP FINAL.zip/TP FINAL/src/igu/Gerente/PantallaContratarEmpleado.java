package igu.Gerente;

import logica.clases.personas.Cajero;
import logica.clases.personas.CargoEmpleado;
import logica.clases.personas.Empleado;
import logica.clases.personas.Gerente;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.MatteBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;

import static logica.clases.Gestora.guardarGerente;


public class PantallaContratarEmpleado extends JFrame {
    public JPanel panelMain;
    private JTextField txt_direc;
    private JTextField txt_puesto;
    private JTextField txt_telefono;
    private JTextField txt_mail;
    private JTextField txt_dni;
    private JTextField txt_apellido;
    private JTextField txt_nombre;
    private JButton btn_registrar;
    private JButton btn_atras;
    private JComboBox box_cargos;
    private JTextField txt_sueldo;
    private JLabel lbl_dni;
    private JLabel lbl_mail;
    private JLabel lbl_tel;
    private JLabel flecha_dni;
    private JLabel flecha_tel;
    private Font robotoFont;

    public PantallaContratarEmpleado(Gerente gerente) {

        configureTextField(txt_nombre);
        configureTextField(txt_apellido);
        configureTextField(txt_dni);
        configureTextField(txt_mail);
        configureTextField(txt_direc);
        configureTextField(txt_telefono);
        configureTextField(txt_puesto);
        configureTextField(txt_sueldo);

        box_cargos.addItem(CargoEmpleado.Cajero);
        box_cargos.addItem(CargoEmpleado.Repositor);
        box_cargos.addItem(CargoEmpleado.Limpieza);

        btn_registrar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

            }
        });

        btn_atras.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });

        btn_registrar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(box_cargos.getSelectedItem() == CargoEmpleado.Cajero){
                    String contra = JOptionPane.showInputDialog(null, "Asigne una contraseña para este cajero.");

                    Cajero cajero = new Cajero(contra, CargoEmpleado.Cajero, Integer.parseInt(txt_sueldo.getText()), txt_nombre.getText(), txt_apellido.getText(), txt_dni.getText(), txt_telefono.getText(), txt_mail.getText(), txt_direc.getText(), LocalDate.now());
                    int res= gerente.contratarEmpleado(cajero);

                    if (res==0){
                        JOptionPane.showMessageDialog(panelMain, "Empelado guardado en el archivo exitosamente!");
                        guardarGerente(gerente,"gerente.txt");
                        dispose();
                    }
                    else if (res == -1){
                        JOptionPane.showMessageDialog(panelMain, "Ya existe un empleado con ese dni.");
                        lbl_dni.setText("Dni  ->");
                        lbl_dni.setForeground(Color.red);
                    }
                    else if (res == -2){
                        JOptionPane.showMessageDialog(panelMain, "Ya existe un empleado con ese mail.");
                        lbl_mail.setText("Mail  ->");
                        lbl_mail.setForeground(Color.red);
                    }else if (res == -3){
                        JOptionPane.showMessageDialog(panelMain, "Ya existe un empleado con ese número de teléfono.");
                        lbl_tel.setText("Teléfono  ->");
                        lbl_tel.setForeground(Color.red);
                    }
                }
                else {
                    Empleado empleado = new Empleado((CargoEmpleado) box_cargos.getSelectedItem(), Integer.parseInt(txt_sueldo.getText()), txt_nombre.getText(), txt_apellido.getText(), txt_dni.getText(), txt_mail.getText(), txt_telefono.getText(), txt_direc.getText(),LocalDate.now());
                    int res=gerente.contratarEmpleado(empleado);

                    if (res==0){
                        JOptionPane.showMessageDialog(panelMain, "Empelado guardado en el archivo exitosamente!");
                        guardarGerente(gerente,"gerente.txt");
                        dispose();
                    }
                    else if (res == -1){
                        JOptionPane.showMessageDialog(panelMain, "Ya existe un empleado con ese dni.");
                        lbl_dni.setText("Dni  ->");
                        lbl_dni.setForeground(Color.red);;
                    }
                    else if (res == -2){
                        JOptionPane.showMessageDialog(panelMain, "Ya existe un empleado con ese mail.");
                        lbl_mail.setText("Mail  ->");
                        lbl_mail.setForeground(Color.red);
                    }else if (res == -3){
                        JOptionPane.showMessageDialog(panelMain, "Ya existe un empleado con ese número de teléfono.");
                        lbl_tel.setText("Teléfono  ->");
                        lbl_tel.setForeground(Color.red);
                    }
                }

            }
        });
    }

    private void configureTextField(JTextField textField) {
        if (textField != null) {
            Color backgroundColor = UIManager.getColor("Panel.background");
            Border bottomBorder = new MatteBorder(0, 0, 1, 0, Color.LIGHT_GRAY);
            Border emptyBorder = new EmptyBorder(0, 0, 5, 0); // Relleno inferior para separación
            Border fieldBorder = new CompoundBorder(bottomBorder, emptyBorder);

            textField.setBorder(fieldBorder);
            textField.setBackground(backgroundColor); // Establecer el color de fondo
            textField.setFont(robotoFont); // Establecer la fuente Roboto
        }
    }

}
