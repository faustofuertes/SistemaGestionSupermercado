package igu.Gerente;

import igu.Cajero.PantallaAllRemitos;
import logica.clases.Gestora;
import logica.clases.personas.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import static logica.clases.Gestora.guardarGerente;

//DNI NO SE PUEDE MODIFICAR PQ ES LA KEY.
public class PantallaVerUnCajero extends JFrame{
    public JPanel panelMain;
    private JButton btn_atras;
    private JPanel panelIcono;
    private JButton btn_despedir;
    private JButton btn_verHistorialVentas;
    private JLabel lbl_icon;
    private JPanel panelInfo;
    private JLabel lbl_apellido;
    private JList list1;
    private JLabel lbl_nombre;
    DefaultListModel model= new DefaultListModel<>();
    private boolean confirmacionDespido;


    public PantallaVerUnCajero(Usuario empleado, Gestora gestora) {

        Cajero cajero = (Cajero) empleado;

        panelInfo.setBorder(BorderFactory.createLineBorder(Color.lightGray, 1));
        panelIcono.setBorder(BorderFactory.createLineBorder(Color.lightGray, 1));

        lbl_nombre.setText(empleado.getNombre());
        lbl_apellido.setText(cajero.getApellido());

        model.addElement("  Dni:  " + cajero.getDni());
        model.addElement("  Nombre:  " + cajero.getNombre());
        model.addElement("  Apellido:  " + cajero.getApellido());
        model.addElement("  Mail:  " + cajero.getMail());
        model.addElement("  Dirección:  " + cajero.getDirec());
        model.addElement("  Teléfono:  " + cajero.getTel());
        model.addElement("  Puesto:  " + cajero.getCargo());
        model.addElement("  Contraseña:  " + cajero.getContrasenia());
        list1.setModel(model);

        list1.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    int index = list1.locationToIndex(e.getPoint());
                    if (index != -1) {

                        String elementoSeleccionado = (String) list1.getModel().getElementAt(index);

                        if (index == 0 || index == 6) {
                            JOptionPane.showMessageDialog(list1, "Este campo no se puede modificar.");
                        } else {
                            String textoIngresado = null;
                            boolean valorValido = false;

                            while (!valorValido) {
                                textoIngresado = JOptionPane.showInputDialog(list1, "Ingrese el nuevo valor:");

                                if (textoIngresado == null) {
                                    return;
                                } else if (textoIngresado.trim().isEmpty()) {
                                    JOptionPane.showMessageDialog(list1, "Debe ingresar un valor.");
                                } else {
                                    valorValido = true;
                                }
                            }

                            if (index == 1) {
                                model.setElementAt("  Nombre:  " + textoIngresado, index);
                                gestora.getGerente().modificarNombre(cajero.getDni(), textoIngresado);
                                lbl_nombre.setText(textoIngresado);
                                guardarGerente(gestora.getGerente(), "gerente.txt");
                            } else if (index == 2) {
                                model.setElementAt("  Apellido:  " + textoIngresado, index);
                                gestora.getGerente().modificarApellido(cajero.getDni(), textoIngresado);
                                lbl_apellido.setText(textoIngresado);
                                guardarGerente(gestora.getGerente(), "gerente.txt");
                            } else if (index == 3) {
                                model.setElementAt("  Mail:  " + textoIngresado, index);
                                gestora.getGerente().modificarMail(cajero.getDni(), textoIngresado);
                                guardarGerente(gestora.getGerente(), "gerente.txt");
                            } else if (index == 5) {
                                model.setElementAt("  Dirección:  " + textoIngresado, index);
                                gestora.getGerente().modificarDirec(cajero.getDni(), textoIngresado);
                                guardarGerente(gestora.getGerente(), "gerente.txt");
                            } else if (index == 7) {
                                model.setElementAt("  Teléfono:  " + textoIngresado, index);
                                gestora.getGerente().modificarTel(cajero.getDni(), textoIngresado);
                                guardarGerente(gestora.getGerente(), "gerente.txt");
                            }
                        }
                    }
                }
            }
        });

        btn_atras.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });

        btn_verHistorialVentas.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                PantallaAllRemitos p = new PantallaAllRemitos(gestora,cajero);

                p.setContentPane(p.panelMain);
                p.setLocation(430, 150);
                p.setTitle("Vista ventas");
                p.setSize(500, 500);
                p.setVisible(true);
                p.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            }
        });

        btn_despedir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int respuesta = JOptionPane.showConfirmDialog(btn_despedir, "¿Deseas continuar?", "Confirmación", JOptionPane.YES_NO_OPTION);

                if (respuesta == JOptionPane.YES_OPTION){
                    gestora.getGerente().despedirEmpleado(cajero.getDni());
                    confirmacionDespido = true;
                    dispose();
                    guardarGerente(gestora.getGerente(),"gerente.txt");
                }

                else
                    JOptionPane.showMessageDialog(null, "Cancelado correctamente");
            }
        });
    }

    public boolean isConfirmacionDespido() {
        return confirmacionDespido;
    }
}
