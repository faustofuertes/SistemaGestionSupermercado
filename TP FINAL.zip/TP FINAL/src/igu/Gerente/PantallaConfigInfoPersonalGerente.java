package igu.Gerente;

import logica.clases.Gestora;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import static logica.clases.Gestora.guardarGerente;

public class PantallaConfigInfoPersonalGerente extends JFrame{
    public JPanel panelMain;
    private JButton btn_atras;
    private JPanel panelIcono;
    private JLabel lbl_icon;
    private JPanel panelInfo;
    private JList list1;
    DefaultListModel model= new DefaultListModel<>();
    private JLabel lbl_nombre;

    public PantallaConfigInfoPersonalGerente(Gestora gestora) {
        panelInfo.setBorder(BorderFactory.createLineBorder(Color.lightGray, 1));
        panelIcono.setBorder(BorderFactory.createLineBorder(Color.lightGray, 1));

        lbl_nombre.setText("  Configuración ");

        model.addElement("  Dni:  " + gestora.getGerente().getDni());
        model.addElement("  Nombre:  " + gestora.getGerente().getNombre());
        model.addElement("  Apellido:  " + gestora.getGerente().getApellido());
        model.addElement("  Mail:  " + gestora.getGerente().getMail());
        model.addElement("  Dirección: " + gestora.getGerente().getDirec());
        model.addElement("  Teléfono:  " + gestora.getGerente().getTel());
        model.addElement("  Puesto:  " + gestora.getGerente().getCargo());
        model.addElement("  Contraseña:  " + gestora.getGerente().getContrasenia());
        list1.setModel(model);

        list1.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    int index = list1.locationToIndex(e.getPoint());
                    if (index != -1) {

                        String elementoSeleccionado = (String) list1.getModel().getElementAt(index);

                        if (index == 0 || index == 6) {
                            JOptionPane.showMessageDialog(list1, "Este campo no se puede modificar.");
                        } else {
                            String textoIngresado = null;
                            boolean valorValido = false;

                            while (!valorValido) {
                                textoIngresado = JOptionPane.showInputDialog(list1, "Ingrese el nuevo valor:");

                                if (textoIngresado == null) {
                                    return;
                                } else if (textoIngresado.trim().isEmpty()) {
                                    JOptionPane.showMessageDialog(list1, "Debe ingresar un valor.");
                                } else {
                                    valorValido = true;
                                }
                            }

                            if (index == 1) {
                                model.setElementAt("  Nombre:  " + textoIngresado, index);
                                gestora.getGerente().modificarNombre(textoIngresado);
                                guardarGerente(gestora.getGerente(), "gerente.txt");
                            } else if (index == 2) {
                                model.setElementAt("  Apellido:  " + textoIngresado, index);
                                gestora.getGerente().modificarApellido(textoIngresado);
                                guardarGerente(gestora.getGerente(), "gerente.txt");
                            } else if (index == 3) {
                                model.setElementAt("  Mail:  " + textoIngresado, index);
                                gestora.getGerente().modificarMail(textoIngresado);
                                guardarGerente(gestora.getGerente(), "gerente.txt");
                            } else if (index == 4) {
                                model.setElementAt("  Dirección:  " + textoIngresado, index);
                                gestora.getGerente().modificarDireccion(textoIngresado);
                                guardarGerente(gestora.getGerente(), "gerente.txt");
                            } else if (index == 5) {
                                model.setElementAt("  Teléfono:  " + textoIngresado, index);
                                gestora.getGerente().modificarTel(textoIngresado);
                                guardarGerente(gestora.getGerente(), "gerente.txt");
                            } else if (index == 7) {
                                model.setElementAt("  Contraseña:  " + textoIngresado, index);
                                gestora.getGerente().modificarContrenia(textoIngresado);
                                guardarGerente(gestora.getGerente(), "gerente.txt");
                            }
                        }
                    }
                }
            }
        });

        btn_atras.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
    }
}

