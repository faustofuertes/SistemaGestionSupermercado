package igu.Cajero;
import logica.clases.Gestora;
import logica.clases.facturacion.Producto;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import java.util.Vector;


public class PantallaProductosBuscados extends JFrame {
    public JPanel panelMain;
    private JTable tabla_produs;
    public Producto produSele=new Producto();
    private DefaultTableModel modeloTabla;
    private int cant;

    public PantallaProductosBuscados(ArrayList<Producto> arrayProductosEncontrados, Gestora gestora) {

        modeloTabla = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                // Hacer que todas las celdas no sean editables
                return false;
            }
        };

        modeloTabla.addColumn("ID");
        modeloTabla.addColumn("DESC");
        modeloTabla.addColumn("PRECIO");
        tabla_produs.setModel(modeloTabla);
        tabla_produs.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);

        TableColumn idColumn = tabla_produs.getColumnModel().getColumn(0);
        TableColumn descColumn = tabla_produs.getColumnModel().getColumn(1);
        TableColumn precioColumn = tabla_produs.getColumnModel().getColumn(2);
        idColumn.setPreferredWidth(50);
        descColumn.setPreferredWidth(175);
        precioColumn.setPreferredWidth(56);

        for(Producto p : arrayProductosEncontrados)
            agregarFila(p);

        tabla_produs.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) { // Verifica si el clic fue doble clic
                    int row = tabla_produs.getSelectedRow();
                    if (row != -1) { // Verifica si se hizo clic en una fila válida
                        produSele = arrayProductosEncontrados.get(row); // Obtiene el producto seleccionado

                        PantallaIngreseCant p = new PantallaIngreseCant();

                        p.setContentPane(p.panelMain);
                        p.setLocation(540, 150);
                        p.setTitle("Ingresar cantidad");
                        p.setSize(300, 200);
                        p.setVisible(true);
                        p.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

                        p.addWindowListener(new WindowAdapter() {
                            @Override
                            public void windowClosed(WindowEvent e) {
                                // Verificar si se agregó un producto válido
                                if (p.getTxt_cant() != null) {
                                    cant=Integer.parseInt(p.getTxt_cant().getText());
                                    dispose();
                                }
                            }
                        });

                    }
                }
            }
        });
    }

    public Producto getProduSele() {
        return produSele;
    }

    public void agregarFila(Producto p){
        Vector<Object> fila = new Vector<>();
        fila.add(p.getId());
        fila.add(p.getDesc());
        fila.add(p.getPrecio());
        modeloTabla.addRow(fila);
    }

    public int getCant() {
        return cant;
    }
}
