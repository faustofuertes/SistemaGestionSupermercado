package igu.Cajero;

import logica.clases.facturacion.Producto;
import logica.clases.facturacion.Remito;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Vector;
import javax.swing.JTable;
import javax.swing.table.TableColumn;


public class PantallaUnRemito extends JFrame{
    private JTable tabla_remito;
    public JPanel panelMain;
    private JLabel txt_infoRemito;
    private JLabel txt_total;
    private JButton btn_atras;
    private DefaultTableModel modeloTabla;

    PantallaUnRemito(Remito remito){
        txt_infoRemito.setText("   Numero de remito: " + remito.getNum() + "        fecha: " + remito.getFecha().toString() + "\n\n");

        modeloTabla = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                // Hacer que todas las celdas no sean editables
                return false;
            }
        };

        modeloTabla.addColumn("ID");
        modeloTabla.addColumn("Desc");
        modeloTabla.addColumn("Cant");
        modeloTabla.addColumn("Precio unidad");
        modeloTabla.addColumn("SubTotal");


        // Asignar el modelo de tabla personalizado a la tabla
        tabla_remito.setModel(modeloTabla);

        TableColumn ID = tabla_remito.getColumnModel().getColumn(0);
        ID.setPreferredWidth(10);
        TableColumn DESC = tabla_remito.getColumnModel().getColumn(1);
        DESC.setPreferredWidth(150);
        TableColumn CANT = tabla_remito.getColumnModel().getColumn(2);
        CANT.setPreferredWidth(20);


        // Agregar filas de ejemplo (puedes reemplazar esto con tus propios datos)
        for (int i=0; i<remito.getArrayProdcutos().size(); i++){
            agregarFila(remito.getArrayProdcutos().get(i));
        }

        txt_total.setText("TOTAL: $" + String.valueOf(remito.calcTotal()));

        btn_atras.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });

    }

    private void agregarFila(Producto producto) {
        Vector<Object> fila = new Vector<>();
        fila.add(producto.getId());
        fila.add(producto.getDesc());
        fila.add(producto.getCant());
        fila.add(producto.getPrecio());
        fila.add(producto.calcTotal());
        modeloTabla.addRow(fila);
    }
}
