package igu.Cajero;

import igu.Admin.PantallaModificacionProdu;
import logica.clases.Gestora;
import logica.clases.facturacion.Producto;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Vector;


public class PantallaBusquedaProductos extends JFrame{
    public JPanel panelMain;
    private JTextField txt_productoBuscado;
    private JButton btn_buscar;
    private JButton btn_atras;
    private JTable tabla_produ;
    private JScrollPane Scroll;
    private JComboBox box_secciones;
    private Gestora gestora=new Gestora();
    private ArrayList<Producto> arrayProductosEncontrados;
    private int index;
    private DefaultTableModel modeloTabla;
    private String seccion;

    public PantallaBusquedaProductos(Gestora gestora, boolean permisoModificacion) {

        modeloTabla = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                // Hacer que todas las celdas no sean editables
                return false;
            }
        };

        modeloTabla.addColumn("ID");
        modeloTabla.addColumn("DESC");
        modeloTabla.addColumn("PRECIO");
        modeloTabla.addColumn("STOCK");
        tabla_produ.setModel(modeloTabla);
        tabla_produ.getTableHeader().setReorderingAllowed(false);

        tabla_produ.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2 && permisoModificacion == true) {

                    int index = tabla_produ.rowAtPoint(e.getPoint());

                    String nombreProduElegido = (String) modeloTabla.getValueAt(index, 1);

                    Producto produElegido = gestora.getAdmin().getInventario().buscaProduConDescYseccion(nombreProduElegido,seccion);

                    if (index != -1) {
                        PantallaModificacionProdu p = new PantallaModificacionProdu(gestora.getAdmin(), produElegido, seccion);

                        p.setContentPane(p.panelMain);
                        p.setLocation(380, 250);
                        p.setTitle("Modificar producto");
                        p.setSize(600, 350);
                        p.setVisible(true);
                        p.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

                        p.addWindowListener(new WindowAdapter() {
                            @Override
                            public void windowClosed(WindowEvent e) {
                                    vaciarTabla(modeloTabla);
                                    arrayProductosEncontrados=gestora.buscaProductoEnArray(gestora.getAdmin().getInventario().getSecciones().get(seccion), txt_productoBuscado.getText());
                                    for (Producto producto : arrayProductosEncontrados)
                                        agregarFila(producto);

                            }
                        });
                    }
                }
            }
        });

        btn_buscar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                vaciarTabla(modeloTabla);
                if (seccion == " " || seccion == null)
                    JOptionPane.showMessageDialog(null, "Porfavor ingrese una seccion en donde buscar los productos.");
                else {

                arrayProductosEncontrados=gestora.buscaProductoEnArray(gestora.getAdmin().getInventario().getSecciones().get(seccion), txt_productoBuscado.getText());

                if(arrayProductosEncontrados == null)
                    JOptionPane.showMessageDialog(btn_buscar, "Producto no encontrado!");
                else{
                    for (Producto producto : arrayProductosEncontrados)
                        agregarFila(producto);
                }
                }
            }
        });

        btn_atras.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });

        box_secciones.addItem(" ");
        box_secciones.addItem("bebidas");
        box_secciones.addItem("alimentos");
        box_secciones.addItem("almacen");
        box_secciones.addItem("lacteos");
        box_secciones.addItem("limpieza");

        box_secciones.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
              seccion= (String) box_secciones.getSelectedItem();
            }
        });
    }

    private void agregarFila(Producto p) {
        Vector<Object> fila = new Vector<>();
        fila.add(p.getId());
        fila.add(p.getDesc());
        fila.add(p.getPrecio());
        fila.add(p.getStock());
        modeloTabla.addRow(fila);
    }

    public void vaciarTabla(DefaultTableModel model) {
        while (model.getRowCount() > 0) {
            model.removeRow(0);
        }
    }
}
