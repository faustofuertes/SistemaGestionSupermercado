package igu.Cajero;

import logica.clases.Gestora;
import logica.clases.personas.Cajero;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PantallaPrincipalCajero extends JFrame{
    public JPanel panelMain;
    private JLabel icon;
    private JToolBar toolBar;
    private JButton btn_menuHacerRemitos;
    private JButton btn_menuVerRemitos;
    private JButton btn_verProductos;
    private JButton btn_cerrarSesion;
    private JLabel lbl_nombre;
    private JLabel lbl_apellido;
    private JLabel lbl_cargo;
    private JButton btn_config;

    public PantallaPrincipalCajero(Cajero cajero, Gestora gestora) {

        toolBar.setFloatable(false);

        lbl_nombre.setText("Nombre: " + cajero.getNombre());
        lbl_apellido.setText("Apellido: " + cajero.getApellido());
        lbl_cargo.setText("Cargo: " + cajero.getCargo());

        btn_menuHacerRemitos.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                PantallaHacerRemito p = new PantallaHacerRemito(cajero,gestora);

                p.setContentPane(p.panelMain);
                p.setLocation(430, 150);
                p.setTitle("Hacer remito");
                p.setSize(500, 500);
                p.setVisible(true);
                p.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            }
        });

        btn_verProductos.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                PantallaBusquedaProductos p = new PantallaBusquedaProductos(gestora, false);

                p.setContentPane(p.panelMain);
                p.setLocation(430, 150);
                p.setTitle("Menu productos");
                p.setSize(500, 500);
                p.setVisible(true);
                p.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            }
        });

        btn_menuVerRemitos.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                PantallaAllRemitos p = new PantallaAllRemitos(gestora,cajero);

                p.setContentPane(p.panelMain);
                p.setLocation(430, 150);
                p.setTitle("Vista remitos");
                p.setSize(500, 500);
                p.setVisible(true);
                p.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            }
        });

        btn_cerrarSesion.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });

        btn_config.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                PantallaConfigCajero p = new PantallaConfigCajero(cajero);

                p.setContentPane(p.panelMain);
                p.setLocation(300, 150);
                p.setTitle("Mi perfil");
                p.setSize(770, 500);
                p.setVisible(true);
                p.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            }
        });
    }
}
