package igu.Cajero;

import logica.clases.Gestora;
import logica.clases.facturacion.Producto;
import logica.clases.facturacion.Remito;
import logica.clases.personas.Cajero;

import javax.swing.*;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;
import java.awt.*;
import java.awt.event.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Vector;

import static logica.clases.Gestora.*;


public class PantallaHacerRemito extends JFrame{

    public JPanel panelMain;
    private JScrollPane SCROLL;
    private JTable tabla_remito;
    private JButton btn_finalizar;
    private JButton btn_atras;
    private JButton btn_eliminar;
    private JButton btn_buscaProducto;
    private JLabel txt_total;
    private JTextField txt_productoBuscado;
    private JComboBox box_secciones;
    private DefaultTableModel modeloTabla;
    private int index;
    private String seccionElegida;
    private double suma;
    private String seccion;

    public PantallaHacerRemito(Cajero cajero, Gestora gestora) {

        txt_total.setBorder(new LineBorder(Color.gray, 1));

        tabla_remito.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 1) {
                    index = tabla_remito.rowAtPoint(e.getPoint());
                    if (index != -1) { // Verifica si se hizo clic en una fila válida
                        System.out.println("Fila seleccionada: " + index);
                    }
                }
            }
        });

        modeloTabla = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                // Hacer que todas las celdas no sean editables
                return column == 2;
            }
        };

        modeloTabla.addColumn("ID");
        modeloTabla.addColumn("DESC");
        modeloTabla.addColumn("CANT");
        modeloTabla.addColumn("PRECIO");
        modeloTabla.addColumn("SUBTOTAL");

        tabla_remito.setModel(modeloTabla);
        tabla_remito.getTableHeader().setReorderingAllowed(false);


        TableColumn ID = tabla_remito.getColumnModel().getColumn(0);
        ID.setPreferredWidth(50);

        TableColumn DESC = tabla_remito.getColumnModel().getColumn(1);
        DESC.setPreferredWidth(200);

        TableColumn CANT = tabla_remito.getColumnModel().getColumn(2);
        CANT.setPreferredWidth(50);

        btn_atras.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });

        btn_eliminar.addActionListener(new ActionListener() { //falta q vuelva a aumentar el stock
            @Override
            public void actionPerformed(ActionEvent e) {
                suma -= (Double) modeloTabla.getValueAt(index, 4);
                txt_total.setText("TOTAL:" + suma);
                modeloTabla.removeRow(index);

            }
        });

        btn_finalizar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                JOptionPane.showMessageDialog(panelMain, "Remito finalizado y guardado en el archivo!");

                ArrayList<Producto> arrayListProductos = new ArrayList<>();

                for (int i = 0; i < tabla_remito.getRowCount(); i++) {
                    String desc = (String) tabla_remito.getValueAt(i, 1);
                    int precio = (int) tabla_remito.getValueAt(i, 3);
                    int cant = (int) tabla_remito.getValueAt(i, 2);

                    Producto producto = new Producto(desc, precio, cant);

                    arrayListProductos.add(producto);
                }

                Remito remitoFinalizado = new Remito(LocalDate.now(), arrayListProductos);

                remitoFinalizado.setNum(cajero.getHistorialVentasCajero().size()+1);
                cajero.getHistorialVentasCajero().add(remitoFinalizado);

                remitoFinalizado.setNum(gestora.getHistorialVentasHistoricas().size()+1);
                gestora.getHistorialVentasHistoricas().add(remitoFinalizado);

                guardarGerente(gestora.getGerente(),"gerente.txt");
                guardarRemitos(gestora.getHistorialVentasHistoricas(),"remitos.txt");

                dispose();
            }
        });

        btn_buscaProducto.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (seccion == " " || seccion == null)
                    JOptionPane.showMessageDialog(null, "Porfavor eliga una seccion antes de buscar un producto");
                else {


                ArrayList<Producto> arrayProductosEncontrados= gestora.buscaProductoEnArray(gestora.getAdmin().getInventario().getSecciones().get(seccion), txt_productoBuscado.getText());

                if(arrayProductosEncontrados == null)
                    JOptionPane.showMessageDialog(btn_buscaProducto, "Producto no encontrado!");
                else {

                    PantallaProductosBuscados p= new PantallaProductosBuscados(arrayProductosEncontrados,gestora);

                    p.setContentPane(p.panelMain);
                    p.setLocation(430, 150);
                    p.setTitle("Seleccionar producto");
                    p.setSize(500, 500);
                    p.setVisible(true);
                    p.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

                    p.addWindowListener(new WindowAdapter() {
                        @Override
                        public void windowClosed(WindowEvent e) {
                            // Verificar si se agregó un producto válido
                            if (p.getProduSele() != null) {
                                //resta stock del inventario
                                if (gestora.getAdmin().getInventario().disminuyeStock(seccion, p.getProduSele(), p.getCant()) == true){
                                    Producto produ = p.getProduSele();
                                    produ.setCant(p.getCant());
                                    agregarFila(produ);
                                    suma+=produ.calcTotal();
                                    txt_total.setText("TOTAL:" + suma);
                                    guardarAdmin(gestora.getAdmin(), "admin.txt");
                                }
                                else
                                    JOptionPane.showMessageDialog(p, "No hay suficiente cantidad en stock.");
                            }
                        }
                    });

                }
                }
            }
        });

        box_secciones.addItem(" ");
        box_secciones.addItem("bebidas");
        box_secciones.addItem("alimentos");
        box_secciones.addItem("almacen");
        box_secciones.addItem("lacteos");
        box_secciones.addItem("limpieza");

        box_secciones.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                seccion = (String) box_secciones.getSelectedItem();
            }
        });
    }

    private void agregarFila(Producto p) {
        Vector<Object> fila = new Vector<>();
        fila.add(p.getId());
        fila.add(p.getDesc());
        fila.add(p.getCant());
        fila.add(p.getPrecio());
        fila.add(p.calcTotal());
        modeloTabla.addRow(fila);
    }
}
