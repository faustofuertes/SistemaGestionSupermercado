package igu.Cajero;

import logica.clases.personas.Cajero;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class PantallaConfigCajero extends JFrame{
    public JPanel panelMain;
    private JButton btn_atras;
    private JPanel panelIcono;
    private JLabel lbl_icon;
    private JPanel panelInfo;
    private JList list1;
    DefaultListModel model= new DefaultListModel<>();
    private JLabel lbl_nombre;

    public PantallaConfigCajero(Cajero empleado) {

        panelInfo.setBorder(BorderFactory.createLineBorder(Color.lightGray, 1));
        panelIcono.setBorder(BorderFactory.createLineBorder(Color.lightGray, 1));

        lbl_nombre.setText("    Mi cuenta  ");

        model.addElement("  Dni: " + empleado.getDni());
        model.addElement("  Nombre: " + empleado.getNombre());
        model.addElement("  Apellido: " + empleado.getApellido());
        model.addElement("  Mail: " + empleado.getMail());
        model.addElement("  Dirección: " +empleado.getDirec());
        model.addElement("  Teléfono: " +empleado.getTel());
        model.addElement("  Puesto: " + empleado.getCargo());
        list1.setModel(model);

        btn_atras.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
    }
}
