package igu.Cajero;

import logica.clases.Gestora;
import logica.clases.facturacion.Remito;
import logica.clases.personas.Cajero;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.Vector;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;


public class PantallaAllRemitos extends JFrame{
    private JLabel txt_remitos;
    private JTable tabla_remitos;
    public JPanel panelMain;
    private JButton btn_atras;
    private JLabel lbl_cant;
    private DefaultTableModel modeloTabla;
    private Remito remitoSelec;

    public PantallaAllRemitos(Gestora gestora) {

        txt_remitos.setText("Cantidad de remitos: " + gestora.getHistorialVentasHistoricas().size());

        modeloTabla = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                // Hacer que todas las celdas no sean editables
                return false;
            }
        };

        modeloTabla.addColumn("Fecha");
        modeloTabla.addColumn("Número de Remito");
        modeloTabla.addColumn("Total ($)");
        tabla_remitos.setModel(modeloTabla);
        tabla_remitos.getTableHeader().setReorderingAllowed(false);

        for(int i=0; i<gestora.getHistorialVentasHistoricas().size(); i++){
            agregarFila(gestora.getHistorialVentasHistoricas().get(i));
        }

        tabla_remitos.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    int index = tabla_remitos.rowAtPoint(e.getPoint());
                    if (index != -1) {
                        remitoSelec = gestora.getHistorialVentasHistoricas().get(index);

                        PantallaUnRemito p= new PantallaUnRemito(remitoSelec);

                        p.setContentPane(p.panelMain);
                        p.setLocation(430, 150);
                        p.setTitle("Remito");
                        p.setSize(500, 500);
                        p.setVisible(true);
                        p.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                    }
                }
            }
        });

        btn_atras.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
    }

    private void agregarFila(Remito remito) {
        Vector<Object> fila = new Vector<>();
        fila.add(remito.getFecha());
        fila.add(remito.getNum());
        fila.add(remito.calcTotal());
        modeloTabla.addRow(fila);
    }


    public PantallaAllRemitos(Gestora gestora,Cajero cajero){

        txt_remitos.setText("Cantidad de remitos: " + cajero.getHistorialVentasCajero().size());

        modeloTabla = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                // Hacer que todas las celdas no sean editables
                return false;
            }
        };

        modeloTabla.addColumn("Fecha");
        modeloTabla.addColumn("Número de Remito");
        modeloTabla.addColumn("Total ($)");
        tabla_remitos.setModel(modeloTabla);
        tabla_remitos.getTableHeader().setReorderingAllowed(false);

        for(int i=0; i<cajero.getHistorialVentasCajero().size(); i++){
            agregarFila(cajero.getHistorialVentasCajero().get(i));
        }

        tabla_remitos.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    int index = tabla_remitos.rowAtPoint(e.getPoint());
                    if (index != -1) {
                        remitoSelec = cajero.getHistorialVentasCajero().get(index);

                        PantallaUnRemito p= new PantallaUnRemito(remitoSelec);

                        p.setContentPane(p.panelMain);
                        p.setLocation(430, 150);
                        p.setTitle("Remito");
                        p.setSize(500, 500);
                        p.setVisible(true);
                        p.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                    }
                }
            }
        });

        btn_atras.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
    }
}
