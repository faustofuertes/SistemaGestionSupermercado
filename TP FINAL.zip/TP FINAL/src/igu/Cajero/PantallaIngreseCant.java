package igu.Cajero;

import logica.clases.excepciones.EmptyInputException;
import logica.clases.excepciones.InvalidNumberException;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PantallaIngreseCant extends JFrame {
    private JTextField txt_cant;
    private JButton btn_listo;
    public JPanel panelMain;
    private JSpinner spinner;
    ImageIcon icon = new ImageIcon("src/img/admin.png");
    public PantallaIngreseCant() {
        btn_listo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {

                    //se guarda el texto en input
                    String input = txt_cant.getText();

                    //se evalua si esta vacio, si lo esta arroja una exception (la crea, y le pasa como parametro el mensaje de error)
                    if (input.isEmpty()) {
                        throw new EmptyInputException("Por favor, ingrese la cantidad que desea de este producto.");
                    }

                    //lo mismo q arriba pero lo evalua de otra manera
                    int cantidad = Integer.parseInt(input);
                    if (cantidad <= 0) {
                        throw new InvalidNumberException("La cantidad debe ser un número positivo.");
                    }

                    //si llega aca es pq no tiene errores
                    dispose();

                    //evalua si se creo alguna de estas exceptions y si se creo tira un showMessege con la exception anteriormente creada
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Error: Ingrese un número válido.", "Error", JOptionPane.ERROR_MESSAGE, icon);
                } catch (EmptyInputException | InvalidNumberException ex) {
                    JOptionPane.showMessageDialog(null, ex.getMessage());
                }
            }
        });
    }

    public JTextField getTxt_cant() {
        return txt_cant;
    }
}