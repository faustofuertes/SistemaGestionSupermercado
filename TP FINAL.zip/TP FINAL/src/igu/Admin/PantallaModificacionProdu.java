package igu.Admin;

import logica.clases.facturacion.Inventario;
import logica.clases.facturacion.Producto;
import logica.clases.personas.Admin;
import logica.clases.personas.Empleado;
import logica.clases.personas.Gerente;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import static logica.clases.Gestora.guardarAdmin;
import static logica.clases.Gestora.guardarGerente;

public class PantallaModificacionProdu extends JFrame{
    public JPanel panelMain;
    private JButton btn_atras;
    private JPanel panelIcono;
    private JButton btn_elminarProdu;
    private JLabel lbl_icon;
    private JPanel panelInfo;
    private JLabel lbl_nombre;
    private JList list1;
    DefaultListModel model= new DefaultListModel<>();
    private boolean confirmacionEliminado;


    public PantallaModificacionProdu(Admin admin, Producto producto, String seccion) {

        if (seccion.equals("bebidas")) {
            ImageIcon icon = new ImageIcon(getClass().getResource("/img/bebidas.png"));
            lbl_icon.setIcon(icon);
        }
        else if (seccion.equals("alimentos")){
            ImageIcon icon = new ImageIcon(getClass().getResource("/img/alimentos.png"));
            lbl_icon.setIcon(icon);
        }
        else if (seccion.equals("almacen")){
            ImageIcon icon = new ImageIcon(getClass().getResource("/img/almacen.png"));
            lbl_icon.setIcon(icon);
        }
        else if (seccion.equals("lacteos")){
            ImageIcon icon = new ImageIcon(getClass().getResource("/img/lacteos.png"));
            lbl_icon.setIcon(icon);
        }
        else if (seccion.equals("limpieza")){
            ImageIcon icon = new ImageIcon(getClass().getResource("/img/limpieza.png"));
            lbl_icon.setIcon(icon);
        }

        panelInfo.setBorder(BorderFactory.createLineBorder(Color.lightGray, 1));
        panelIcono.setBorder(BorderFactory.createLineBorder(Color.lightGray, 1));

        lbl_nombre.setText(seccion);

        model.addElement("  ID: " + producto.getId());
        model.addElement("  Descripción: " + producto.getDesc());
        model.addElement("  Precio: " + producto.getPrecio());
        model.addElement("  Stock: " + producto.getStock());
        list1.setModel(model);

        list1.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    int index = list1.locationToIndex(e.getPoint());
                    if (index != -1) {

                        String elementoSeleccionado = (String) list1.getModel().getElementAt(index);

                        if (index == 0) {
                            JOptionPane.showMessageDialog(list1, "Este campo no se puede modificar.");
                        } else {
                            String textoIngresado = null;
                            boolean valorValido = false;

                            while (!valorValido) {
                                textoIngresado = JOptionPane.showInputDialog(list1, "Ingrese el nuevo valor:");

                                if (textoIngresado == null) {
                                    return;
                                } else if (textoIngresado.trim().isEmpty()) {
                                    JOptionPane.showMessageDialog(list1, "Debe ingresar un valor.");
                                } else {
                                    valorValido = true;
                                }
                            }

                            if (index == 1) {
                                model.setElementAt("  Descripción: " + textoIngresado, index);
                                admin.modificarNombreProductoInventario(seccion, producto.getDesc(), textoIngresado.toLowerCase());
                            } else if (index == 2) {
                                model.setElementAt("  Precio: " + textoIngresado, index);
                                admin.modificarPrecioProductoInventario(seccion, producto.getDesc(), Integer.parseInt(textoIngresado));
                            } else if (index == 3) {
                                model.setElementAt("  Stock: " + textoIngresado, index);
                                admin.modificarStockProductoInventario(seccion, producto.getDesc(), Integer.parseInt(textoIngresado));
                            }

                            guardarAdmin(admin, "admin.txt");
                        }
                    }
                }
            }
        });

        btn_elminarProdu.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int respuesta = JOptionPane.showConfirmDialog(btn_elminarProdu, "¿Deseas continuar?", "Confirmación", JOptionPane.YES_NO_OPTION);

                if (respuesta == JOptionPane.YES_OPTION){
                    admin.darDeBajaUnProducto(seccion, producto.getDesc());
                    confirmacionEliminado = true;
                    guardarAdmin(admin,"admin.txt");
                    dispose();
                }

                else
                    JOptionPane.showMessageDialog(null, "Cancelado correctamente");
            }

        });

        btn_atras.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
    }

    public boolean isConfirmacionEliminado() {
        return confirmacionEliminado;
    }
}
