package igu.Admin;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PantallaIngreseDatosUnProducto extends  JFrame{
    public JPanel panelMain;
    private JComboBox comboBox1;
    private JTextField txt_produBuscado;
    private JButton btn_buscar;
    private String seccion;
    private String produBuscado;

    public PantallaIngreseDatosUnProducto() {

        comboBox1.addItem(" ");
        comboBox1.addItem("bebidas");
        comboBox1.addItem("alimentos");
        comboBox1.addItem("almacen");
        comboBox1.addItem("lacteos");
        comboBox1.addItem("limpieza");

        btn_buscar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (comboBox1.getSelectedItem() != null && !comboBox1.getSelectedItem().equals(" ") && txt_produBuscado != null){
                    seccion = (String) comboBox1.getSelectedItem();
                    produBuscado = txt_produBuscado.getText().toLowerCase();

                    dispose();
                }
                else {
                    JOptionPane.showMessageDialog(null, "Porfavor complete ambos campos");
                }

            }
        });
    }

    public String getSeccion() {
        return seccion;
    }

    public String getProduBuscado() {
        return produBuscado;
    }
}
