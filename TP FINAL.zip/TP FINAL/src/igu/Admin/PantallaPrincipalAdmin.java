package igu.Admin;

import igu.Cajero.PantallaAllRemitos;
import igu.Cajero.PantallaBusquedaProductos;
import logica.clases.Gestora;
import logica.clases.facturacion.Producto;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class PantallaPrincipalAdmin extends JFrame{
    public JPanel panelMain;
    private JLabel icon;
    private JToolBar toolBar;
    private JButton btn_verInventario;
    private JButton btn_buscarUnProducto;
    private JButton btn_agregarProducto;
    private JButton btn_verAllRemitos;
    private JButton btn_atras;
    private JLabel lbl_cargo;
    private JLabel lbl_apellido;
    private JLabel lbl_nombre;
    private JButton btn_config;

    public PantallaPrincipalAdmin(Gestora gestora) {

        toolBar.setFloatable(false);

        lbl_nombre.setText("Nombre:   " + gestora.getAdmin().getNombre());
        lbl_apellido.setText("Apellido:   " + gestora.getAdmin().getApellido());
        lbl_cargo.setText("Cargo:   " + gestora.getAdmin().getCargo());

        btn_verInventario.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                PantallaBusquedaProductos p = new PantallaBusquedaProductos(gestora, true);

                p.setContentPane(p.panelMain);
                p.setLocation(430, 150);
                p.setTitle("Inventario");
                p.setSize(500, 500);
                p.setVisible(true);
                p.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            }
        });

        btn_buscarUnProducto.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                PantallaIngreseDatosUnProducto p = new PantallaIngreseDatosUnProducto();

                p.setContentPane(p.panelMain);
                p.setLocation(450, 280);
                p.setTitle("Menu productos");
                p.setSize(380, 260);
                p.setVisible(true);
                p.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

                p.addWindowListener(new WindowAdapter() {
                    @Override
                    public void windowClosed(WindowEvent e) {
                        String seccion = p.getSeccion();
                        String producto = p.getProduBuscado();

                        Producto produBuscado = gestora.getAdmin().getInventario().buscaProduConDescYseccion(producto, seccion);

                        if (produBuscado == null)
                            JOptionPane.showMessageDialog(null, "Ese producto no existe en el archivo o en esta sección.");
                        else {

                            PantallaModificacionProdu p = new PantallaModificacionProdu(gestora.getAdmin(), produBuscado, seccion);

                            p.setContentPane(p.panelMain);
                            p.setLocation(380, 250);
                            p.setTitle("Modificar producto");
                            p.setSize(600, 350);
                            p.setVisible(true);
                            p.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                        }
                    }
                });
            }
        });

        btn_verAllRemitos.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                PantallaAllRemitos p = new PantallaAllRemitos(gestora);

                p.setContentPane(p.panelMain);
                p.setLocation(430, 150);
                p.setTitle("Vista remitos");
                p.setSize(500, 500);
                p.setVisible(true);
                p.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            }
        });

        btn_agregarProducto.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                PantallaCargaProducto p = new PantallaCargaProducto(gestora);

                p.setContentPane(p.panelMain);
                p.setLocation(500, 240);
                p.setTitle("Agregar un producto");
                p.setSize(350, 350);
                p.setVisible(true);
                p.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            }
        });

        btn_config.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                PantallaConfigInfoPersonalAdmin p = new PantallaConfigInfoPersonalAdmin(gestora);

                p.setContentPane(p.panelMain);
                p.setLocation(300, 150);
                p.setTitle("Mi perfil");
                p.setSize(770, 500);
                p.setVisible(true);
                p.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            }
        });

        btn_atras.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
    }
}

