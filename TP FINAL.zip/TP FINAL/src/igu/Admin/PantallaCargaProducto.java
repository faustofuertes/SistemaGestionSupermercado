package igu.Admin;

import logica.clases.Gestora;
import logica.clases.facturacion.Producto;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import static logica.clases.Gestora.guardarAdmin;

public class PantallaCargaProducto extends JFrame{
    public JPanel panelMain;
    private JTextField txt_stock;
    private JTextField txt_precio;
    private JTextField txt_desc;
    private JButton btn_agregar;
    private JButton btn_atras;
    private JComboBox box_secciones;

    public PantallaCargaProducto(Gestora gestora) {

        Gestora.configureTextField(txt_desc);
        Gestora.configureTextField(txt_precio);
        Gestora.configureTextField(txt_stock);

        box_secciones.addItem(" ");
        box_secciones.addItem("bebidas");
        box_secciones.addItem("alimentos");
        box_secciones.addItem("almacen");
        box_secciones.addItem("lacteos");
        box_secciones.addItem("limpieza");

        btn_agregar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                if (txt_desc == null || txt_precio== null || txt_stock==null || box_secciones.equals(" "))
                    JOptionPane.showMessageDialog(null, "Porfavor complete todos los campos para continuar.");
                else {
                    Producto nuevoProdu = new Producto(Integer.parseInt(txt_stock.getText()), txt_desc.getText().toLowerCase(), Integer.parseInt(txt_precio.getText()));

                    gestora.getAdmin().getInventario().agregarProducto(box_secciones.getSelectedItem().toString(), nuevoProdu);

                }
                guardarAdmin(gestora.getAdmin(),"admin.txt");
                dispose();
            }
        });

        btn_atras.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
    }
}
