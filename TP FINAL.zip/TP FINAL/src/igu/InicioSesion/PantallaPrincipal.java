package igu.InicioSesion;

import igu.Admin.PantallaPrincipalAdmin;
import igu.Cajero.PantallaPrincipalCajero;
import igu.Gerente.PantallaPrincipalGerente;
import logica.clases.Gestora;
import logica.clases.personas.Cajero;
import logica.clases.personas.Empleado;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class PantallaPrincipal extends JFrame{
    public JPanel panelMain;
    private JTextField txt_dni;
    private JPasswordField txt_contra;
    private JComboBox comboBox1;
    private JLabel iconUser;
    private JButton btn_ingresar;
    private JPanel paneUsu;


    public PantallaPrincipal(Gestora gestora) {

        cargaTextFields();

        Gestora.configureTextField(txt_dni);
        Gestora.configureTextField(txt_contra);
        btn_ingresar.requestFocusInWindow();

        PantallaPrincipal.cargarComboBox(comboBox1);

        btn_ingresar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                if (comboBox1.getSelectedItem().equals("cajero")){

                    if (gestora.getGerente().getEmpleados().containsKey(txt_dni.getText())) {

                        Empleado emple = gestora.getGerente().getEmpleados().get(txt_dni.getText());

                        if (emple instanceof Cajero) {

                            Cajero cajero= (Cajero) emple;

                            if (txt_contra.getText().equals(cajero.getContrasenia())){

                                PantallaPrincipalCajero p= new PantallaPrincipalCajero(cajero, gestora);

                                p.setContentPane(p.panelMain);
                                p.setLocation(110, 100);
                                p.setTitle("Menú cajero");
                                p.setSize(1140, 600);
                                p.setVisible(true);
                                p.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

                                p.addWindowListener(new WindowAdapter() {
                                    @Override
                                    public void windowClosed(WindowEvent e) {
                                        txt_dni.setEditable(true);
                                        txt_dni.setText("");
                                        txt_contra.setEditable(true);
                                        txt_contra.setText("");
                                        comboBox1.removeAllItems();
                                        comboBox1.setEditable(true);
                                        PantallaPrincipal.cargarComboBox(comboBox1);
                                        cargaTextFields();
                                    }
                                });

                            }
                            else
                                JOptionPane.showMessageDialog(paneUsu, "Contraseña incorrecta.");
                        }
                        else
                            JOptionPane.showMessageDialog(paneUsu, "Empleado no registrado como cajero.");
                    }
                    else
                        JOptionPane.showMessageDialog(paneUsu, "Empleado no encontrado.");
                }
                else if (comboBox1.getSelectedItem().equals("gerente")) {

                    if(txt_dni.getText().equals(gestora.getGerente().getDni()) && txt_contra.getText().equals(gestora.getGerente().getContrasenia())){

                        PantallaPrincipalGerente p= new PantallaPrincipalGerente(gestora);

                        p.setContentPane(p.panelMain);
                        p.setLocation(110, 100);
                        p.setTitle("Menú gerente");
                        p.setSize(1170, 600);
                        p.setVisible(true);
                        p.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

                        p.addWindowListener(new WindowAdapter() {
                            @Override
                            public void windowClosed(WindowEvent e) {
                                txt_dni.setEditable(true);
                                txt_dni.setText("");
                                txt_contra.setEditable(true);
                                txt_contra.setText("");
                                comboBox1.removeAllItems();
                                comboBox1.setEditable(true);
                                PantallaPrincipal.cargarComboBox(comboBox1);
                                cargaTextFields();
                            }
                        });

                    }
                    else
                        JOptionPane.showMessageDialog(paneUsu, "Gerente no registrado, intente nuevamente.");

                }
                else if (comboBox1.getSelectedItem().equals("administrador")) {

                    if(txt_dni.getText().equals(gestora.getAdmin().getDni()) && txt_contra.getText().equals(gestora.getAdmin().getContrasenia())){

                        PantallaPrincipalAdmin p= new PantallaPrincipalAdmin(gestora);

                        p.setContentPane(p.panelMain);
                        p.setLocation(110, 100);
                        p.setTitle("Menú administrador");
                        p.setSize(1140, 600);
                        p.setVisible(true);
                        p.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

                        p.addWindowListener(new WindowAdapter() {
                            @Override
                            public void windowClosed(WindowEvent e) {
                                txt_dni.setEditable(true);
                                txt_dni.setText("");
                                txt_contra.setEditable(true);
                                txt_contra.setText("");
                                comboBox1.removeAllItems();
                                comboBox1.setEditable(true);
                                PantallaPrincipal.cargarComboBox(comboBox1);
                                cargaTextFields();
                            }
                        });

                    }
                    else
                        JOptionPane.showMessageDialog(paneUsu, "Administrador no registrado, intente nuevamente.");

                }
                else{
                    JOptionPane.showMessageDialog(paneUsu, "Porfavor revise los datos ingresados");
                }

            }
        });
    }

    private static void cargarComboBox(JComboBox box){
        box.addItem(" ");
        box.addItem("cajero");
        box.addItem("gerente");
        box.addItem("administrador");
    }

    private void cargaTextFields(){

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowOpened(WindowEvent e) {
                btn_ingresar.requestFocusInWindow();
            }
        });

        txt_dni.addFocusListener(new FocusListener() {
            @Override
            public void focusGained(FocusEvent e) {
                if (txt_dni.getText().equals("dni")) {
                    txt_dni.setText("");
                    txt_dni.setForeground(Color.BLACK);
                }
            }

            @Override
            public void focusLost(FocusEvent e) {
                if (txt_dni.getText().isEmpty()) {
                    txt_dni.setForeground(Color.GRAY);
                    txt_dni.setText("dni");
                }
            }
        });

        txt_contra.setText("123");
        txt_contra.setForeground(Color.GRAY);
        txt_contra.addFocusListener(new FocusListener() {
            @Override
            public void focusGained(FocusEvent e) {
                if (txt_contra.getText().equals("123")) {
                    txt_contra.setText("");
                    txt_contra.setForeground(Color.BLACK);
                }
            }

            @Override
            public void focusLost(FocusEvent e) {
                if (txt_contra.getText().isEmpty()) {
                    txt_contra.setForeground(Color.GRAY);
                    txt_contra.setText("123");
                }
            }
        });
    }

}
