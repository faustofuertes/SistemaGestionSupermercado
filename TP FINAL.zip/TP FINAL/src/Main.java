import com.formdev.flatlaf.FlatLightLaf;
import com.formdev.flatlaf.themes.FlatMacLightLaf;
import logica.clases.Frame;
import logica.clases.Gestora;
import logica.clases.facturacion.Remito;
import logica.clases.personas.*;
import java.io.*;
import java.util.ArrayList;

//dni gerente:44534191   contra:1234
//dni cajero:455764322   contra:123
//dni admin:12345   contra:1234

public class Main {
    public static void main(String[] args) {
        Gestora gestora=new Gestora();
        FlatLightLaf.registerCustomDefaultsSource("style");
        FlatLightLaf.setup();
        Frame frame=new Frame();

        gestora.cargarAdmin(cargarAdmin("admin.txt"));
        gestora.setHistorialVentasHistoricas(cargarRemitos("remitos.txt"));
        gestora.cargarGerente(cargarGerente("gerente.txt"));


        frame.ejecutarJframe(gestora);


        guardarRemitos(gestora.getHistorialVentasHistoricas(),"remitos.txt");
        guardarGerente(gestora.getGerente(),"gerente.txt");
        guardarAdmin(gestora.getAdmin(),"admin.txt");
    }

    public static void guardarGerente(Gerente gerente, String archivo) {
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(archivo))) {
            out.writeObject(gerente);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static Gerente cargarGerente(String archivo) {
        Gerente gerente = new Gerente();
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(archivo))) {
            gerente = (Gerente) in.readObject();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return gerente;
    }

    public static void guardarRemitos(ArrayList<Remito>arrayHistoricoRemitos, String archivo) {
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(archivo))) {
            out.writeObject(arrayHistoricoRemitos);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static ArrayList cargarRemitos(String archivo) {
        ArrayList<Remito> remitos = new ArrayList<>();
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(archivo))) {
            remitos = (ArrayList<Remito>) in.readObject();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return remitos;
    }

    public static Admin cargarAdmin(String archivo) {
        Admin admin=new Admin();
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(archivo))) {
            admin = (Admin) in.readObject();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return admin;
    }

    public static void guardarAdmin(Admin admin, String archivo) {
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(archivo))) {
            out.writeObject(admin);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}