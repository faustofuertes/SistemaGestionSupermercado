package logica.clases;

import logica.clases.facturacion.Producto;
import logica.clases.facturacion.Remito;
import logica.clases.personas.*;
import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.MatteBorder;
import java.awt.*;
import java.io.*;
import java.util.ArrayList;

public class Gestora implements Serializable {

    private ArrayList<Remito> historialVentasHistorica;
    private Gerente gerente;
    private Admin admin;

    public Gestora(){
        this.historialVentasHistorica=new ArrayList<>();
        this.gerente=null;
        this.admin=null;
    }

    public void cargarGerente(Gerente gerente){
        this.gerente=gerente;
    }

    public void despedirGerente(){
        this.gerente=null;
    }

    public void cargarAdmin(Admin admin){
        this.admin=admin;
    }

    public void despedirAdmin(){
        this.admin=null;
    }

    public ArrayList<Remito> getHistorialVentasHistoricas() {
        return historialVentasHistorica;
    }

    public void setHistorialVentasHistoricas(ArrayList<Remito> historialVentasHistoricas) {
        this.historialVentasHistorica = historialVentasHistoricas;
    }

    public Admin getAdmin() {
        return admin;
    }

    public void setAdmin(Admin admin) {
        this.admin = admin;
    }

    public Gerente getGerente() {
        return gerente;
    }

    public void setGerente(Gerente gerente) {
        this.gerente = gerente;
    }

    public static void guardarGerente(Gerente gerente, String archivo) {
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(archivo))) {
            out.writeObject(gerente);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void guardarRemitos(ArrayList<Remito>arrayHistoricoRemitos, String archivo) {
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(archivo))) {
            out.writeObject(arrayHistoricoRemitos);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void guardarAdmin(Admin admin, String archivo) {
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(archivo))) {
            out.writeObject(admin);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public ArrayList<Producto> buscaProductoEnArray(ArrayList<Producto> arrayProductos, String productoAbuscar){

        ArrayList<Producto> arrayProductosEncontrados=new ArrayList<Producto>();

        for(int i = 0; i < arrayProductos.size(); i++){

            if(arrayProductos.get(i).getDesc().toLowerCase().contains(productoAbuscar.toLowerCase())){
                arrayProductosEncontrados.add(arrayProductos.get(i));
            }
        }

        if (!arrayProductosEncontrados.isEmpty())
            return arrayProductosEncontrados;
        else
            return null;

    }

    public void eliminaProductoDelArray(ArrayList<Producto> arrayProductos, Producto aEliminar){
        arrayProductos.remove(aEliminar);
    }

    public static void configureTextField(JTextField textField) {
        if (textField != null) {
            Color backgroundColor = UIManager.getColor("Panel.background");
            Border bottomBorder = new MatteBorder(0, 0, 1, 0, Color.LIGHT_GRAY);
            Border emptyBorder = new EmptyBorder(0, 0, 5, 0); // Relleno inferior para separación
            Border fieldBorder = new CompoundBorder(bottomBorder, emptyBorder);

            textField.setBorder(fieldBorder);
            //textField.setBackground(backgroundColor); // Establecer el color de fondo
        }
    }

}
