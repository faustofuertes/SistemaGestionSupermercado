package logica.clases.personas;

import logica.clases.facturacion.Inventario;
import logica.clases.facturacion.Producto;
import logica.clases.facturacion.Remito;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.*;

//admin modifica todos los campos del sistema.
public class Admin extends Usuario implements ModificarDatos,Serializable {

    private Inventario inventario;

    public Admin(CargoEmpleado cargo, double sueldo, String nombre, String apellido, String dni, String tel, String mail, String direc, String contrasenia, LocalDate fechaDeIngreso) {
        super(contrasenia,cargo,sueldo,nombre,apellido,dni,tel,mail,direc,fechaDeIngreso );
        this.inventario=new Inventario();
    }

    public Admin(CargoEmpleado cargo, String nombre, String apellido, String dni, String tel,String mail, String direc,String contrasenia,LocalDate fechaIngreso) {
        super(contrasenia,cargo,nombre,apellido,dni,tel,mail,direc, fechaIngreso);
        this.inventario=new Inventario();
    }
    public Admin(){

    }

    @Override
    public void modificarNombre(String nombre) {
        this.setNombre(nombre);
    }

    @Override
    public void modificarApellido(String apellido) {
        this.setApellido(apellido);
    }

    @Override
    public void modificarTel(String telefono) {
        this.setTel(telefono);
    }

    @Override
    public void modificarDireccion(String direccion) {
        this.setDirec(direccion);
    }

    @Override
    public void modificarContrenia(String contrasenia) {
        this.setContrasenia(contrasenia);
    }

    @Override
    public void modificarMail(String mail) {
        this.setMail(mail);
    }

    ///////////////////////////////////////////////GestionInventario//////////////////////////////////////////////////////////

    public boolean modificarProductoInventario(String seccion, String nombreProducto, Producto nuevoProducto) {
        ArrayList<Producto> productos = inventario.getSecciones().get(seccion);
        if (productos != null) {
            for (int i = 0; i < productos.size(); i++) {
                if (productos.get(i).getDesc().equals(nombreProducto)) {
                    productos.set(i, nuevoProducto);
                    return true;
                }
            }
        }
        return false;
    }//remplaza el producto por uno nuevo por parametro

    public boolean modificarStockProductoInventario(String seccion, String nombreProducto, int stock) {
        ArrayList<Producto> productos = inventario.getSecciones().get(seccion);
        if (productos != null) {
            for (Producto producto : productos) {
                if (producto.getDesc().equals(nombreProducto)) {
                    producto.setStock(stock);
                    return true;
                }
            }
        }
        return false;
    }//remplaza el stock del producto seleccionado

    public boolean modificarPrecioProductoInventario(String seccion, String nombreProducto, int precio) {
        ArrayList<Producto> productos = inventario.getSecciones().get(seccion);
        if (productos != null) {
            for (Producto producto : productos) {
                if (producto.getDesc().equals(nombreProducto)) {
                    producto.setPrecio(precio);
                    return true;
                }
            }
        }
        return false;
    }


    public boolean modificarNombreProductoInventario(String seccion, String nombreProducto, String nombreNew) {
        ArrayList<Producto> productos = inventario.getSecciones().get(seccion);
        if (productos != null) {
            for (Producto producto : productos) {
                if (producto.getDesc().equals(nombreProducto)) {
                    producto.setDesc(nombreNew);
                    return true;
                }
            }
        }
        return false;

    }//remplaza el nombre del producto seleccionado

    public boolean darDeBajaUnProducto(String seccion, String nombreProducto){
        ArrayList<Producto> productos = inventario.getSecciones().get(seccion);
        if (productos != null) {
            for (Producto producto : productos) {
                if (producto.getDesc().equals(nombreProducto)) {
                    productos.remove(producto);
                    return true;
                }
            }
        }
        return false;


    }//da de baja un producto usando un metodo de la clase producto

    public void darDeAltaUnProducto(String seccion, Producto producto){
        inventario.agregarProducto(seccion,producto);
    }

    public boolean modificarSeccion(String seccionActual, String seccionNueva) {
        // Obtener la lista de productos de la sección actual
        TreeMap<String, ArrayList<Producto>> secciones = inventario.getSecciones();
        ArrayList<Producto> productos = secciones.get(seccionActual);
        if (productos != null) {
            // Eliminar la entrada con el nombre de la sección actual
            secciones.remove(seccionActual);
            // Agregar una nueva entrada con el nuevo nombre de la sección y la lista de productos
            secciones.put(seccionNueva, productos);
            return true;
        }
        return false;
    }//este metodo elimina la entrada al tree map de una seccion y crea una nueva con otro nombre, y le asocia el arraylist de la seccion anterior.

    public Inventario getInventario() {
        return inventario;
    }

    public void setInventario(Inventario inventario) {
        this.inventario = inventario;
    }

}
