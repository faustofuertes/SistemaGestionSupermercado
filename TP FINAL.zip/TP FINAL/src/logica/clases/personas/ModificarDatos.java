package logica.clases.personas;


public interface ModificarDatos  {
    void modificarNombre(String nombre);
    void modificarApellido(String dni);
    void modificarTel(String telefono);
    void modificarMail(String mail);
    void modificarDireccion(String direccion);
    void modificarContrenia(String contrasenia);
}
