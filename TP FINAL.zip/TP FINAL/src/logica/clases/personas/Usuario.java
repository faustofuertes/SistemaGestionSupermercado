package logica.clases.personas;

import java.io.Serializable;
import java.time.LocalDate;

public class Usuario extends Empleado  implements Serializable{

    protected String contrasenia;


    public Usuario(String contrasenia, CargoEmpleado cargo, double sueldo, String nombre, String apellido, String dni, String tel, String mail, String direc, LocalDate fechaDeIngrso) {
        super(cargo, sueldo, nombre, apellido, dni, tel,mail,direc,fechaDeIngrso);
        this.contrasenia = contrasenia;
    }
    public Usuario(){

    }
    public Usuario(String contrasenia, CargoEmpleado cargo, String nombre, String apellido, String dni, String tel,String mail, String direc,LocalDate fechaDeIngreso) {
        super(cargo, nombre, apellido, dni, tel,mail,direc,fechaDeIngreso);
        this.contrasenia = contrasenia;
    }

    public String getContrasenia() {
        return contrasenia;
    }

    public void setContrasenia(String contrasenia) {
        this.contrasenia = contrasenia;
    }

}
