package logica.clases.personas;

import logica.clases.facturacion.Remito;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;

//gerente solo modifica a los empleados
public class Gerente extends Usuario implements  ModificarDatos,Serializable {

    private HashMap<String, Empleado> empleados;

    public Gerente(CargoEmpleado cargo, double sueldo, String nombre, String apellido, String dni, String tel, String mail, String direc, String contrasenia, LocalDate fechaDeIngreo) {
        super(contrasenia,cargo,sueldo,nombre,apellido,dni,tel,mail,direc,fechaDeIngreo);
        this.empleados=new HashMap<>();
    }

    public Gerente(CargoEmpleado cargo, String nombre, String apellido, String dni, String tel,String mail, String direc, String contrasenia,LocalDate fechaDeIingreso) {
        super(contrasenia,cargo,nombre,apellido,dni,tel,mail, direc,fechaDeIingreso);
        this.empleados=new HashMap<>();
    }
    public Gerente(){

    }

    @Override
    public void modificarNombre(String nombre) {
        this.setNombre(nombre);
    }

    @Override
    public void modificarApellido(String apellido) {
        this.setApellido(apellido);
    }

    @Override
    public void modificarTel(String telefono) {
        this.setTel(telefono);
    }

    @Override
    public void modificarDireccion(String direccion) {
        this.setDirec(direccion);
    }

    @Override
    public void modificarContrenia(String contrasenia) {
        this.setContrasenia(contrasenia);
    }

    @Override
    public void modificarMail(String mail) {
        this.setMail(mail);
    }

    public Empleado despedirEmpleado(String dni){
        return empleados.remove(dni);
    }

    //retorna true si no hay nada repetido.
    public <T extends Empleado>int verificarEmpleado(T empleado){
        //retorna -1 si el dni esta repetido.
        //retorna -2 si el mail esta repetido.
        //retorna -3 si el cel esta repetido.
        //retorna -4 si ya hay un admin contratado.
        //retorna -5 si ya hay un gerente contratado.

        if(empleados.containsKey(empleado.getDni())){
            return -1;
        }else{
            ArrayList<Empleado>array=new ArrayList<>(empleados.values());
            for(Empleado i:array){
                if(i.getMail().equals(empleado.getMail())){
                    return -2;
                }else if(i.getTel().equals(empleado.getTel())){
                    return -3;
                }
            }
        }
        if(empleado instanceof Admin){
            boolean hayAdmin = empleados.values().stream().anyMatch(value -> value instanceof Admin);
            if(hayAdmin){
                return -4;
            }
        }else if(empleado instanceof Gerente){
            boolean hayGerente = empleados.values().stream().anyMatch(value -> value instanceof Gerente);
            if(hayGerente){
                return -5;
            }
        }
        return 0;
    }

    public <T extends Empleado> int contratarEmpleado(T empleado){
        int res=verificarEmpleado(empleado);
        if(res==0){
            if(empleado instanceof Cajero cajero) {
                empleados.put(cajero.getDni(),cajero);
                return res;
            }
            empleados.put(empleado.getDni(), empleado);
        }
        return res;
    }

    public boolean modificarSueldo(String dni,double nuevoSueldo){
        if(empleados.containsKey(dni)){
            empleados.get(dni).setSueldo(nuevoSueldo);
            return true;
        }
        return false;
    }

    public boolean modificarSueldoXporcentaje(String dni,double porcentaje){
        if(empleados.containsKey(dni)){
            Empleado empleado=empleados.get(dni);
            double res=((empleado.getSueldo())*(porcentaje/100));
            empleado.setSueldo(empleado.getSueldo()+res);
            return true;
        }
        return false;
    }

    public boolean modificarCargo(String dni,CargoEmpleado cargoNuevo){
        if(empleados.containsKey(dni)){
            empleados.get(dni).setCargo(cargoNuevo);
            return true;
        }
        return false;
    }

    public boolean modificarNombre(String dni,String nombre){
        if(empleados.containsKey(dni)){
            empleados.get(dni).setNombre(nombre);
            return true;
        }
        return false;
    }

    public boolean modificarApellido(String dni,String apellido){
        if(empleados.containsKey(dni)){
            empleados.get(dni).setApellido(apellido);
            return true;
        }
        return false;
    }

    public boolean modificarContrasenia(String dni,String contrasenia){
        if(empleados.containsKey(dni)){
            if(empleados.get(dni)instanceof Usuario u) {
                u.setContrasenia(contrasenia);
                return true;
            }
        }
        return false;
    }

    public boolean modificarMail(String dni,String nuevoMail){
        if(empleados.containsKey(dni)){
                empleados.get(dni).setMail(nuevoMail);
                return true;
        }
        return false;
    }

    public boolean modificarDirec(String dni,String nuevaDirec){
        if(empleados.containsKey(dni)){
                empleados.get(dni).setDirec(nuevaDirec);
                return true;
        }
        return false;
    }

    public boolean modificarTel(String dni,String nuevoTel){
        if(empleados.containsKey(dni)){
                empleados.get(dni).setTel(nuevoTel);
                return true;
        }
        return false;
    }


    public ArrayList<Empleado> retornarArrayEmpleadoOrdenadoXdni(){
        ArrayList<Empleado>array=new ArrayList<>(empleados.values());
        Collections.sort(array);
        return array;

    }

    public Empleado retornarEmpleadoEspecifico(String dni){
        return empleados.get(dni);
    }


    public ArrayList<Empleado> retornarArrayEmpleadosXcargo() {
        ArrayList<Empleado> empleadosOrdenados = new ArrayList<>(empleados.values());
        Collections.sort(empleadosOrdenados, new Comparator<Empleado>() {
            @Override
            public int compare(Empleado e1, Empleado e2) {
                return e1.getCargo().compareTo(e2.getCargo());
            }
        });
        return empleadosOrdenados;
    }

    public HashMap<String, Empleado> getEmpleados() {
        return empleados;
    }

    public void setEmpleados(HashMap<String, Empleado> empleados) {
        this.empleados = empleados;
    }




    public ArrayList arrayListOrdenadoPorCargo()
    {
        ArrayList<Empleado>empleadoArrayList=new ArrayList<>(empleados.values());

        empleadoArrayList.sort(comparatorByCargo());

        return empleadoArrayList;
    }

    public ArrayList arrayListOrdenarPorFechaDeIngreso()
    {
        ArrayList<Empleado>empleadoArrayList=new ArrayList<>(empleados.values());

        empleadoArrayList.sort(comparatorPorFechaDeIngreso());

        return empleadoArrayList;
    }


}


