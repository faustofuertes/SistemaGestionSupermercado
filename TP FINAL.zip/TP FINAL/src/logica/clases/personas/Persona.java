package logica.clases.personas;

import java.io.Serializable;
import java.time.LocalDate;

public abstract class Persona implements Serializable {

    protected String nombre;
    protected String apellido;
    protected String dni;
    protected String tel;
    protected String mail;
    protected String direc;
    protected LocalDate fechaDeIngreso;

    public Persona(String nombre, String apellido, String dni, String tel , String mail, String direc,LocalDate fechaDeIngreso) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.dni = dni;
        this.tel = tel;
        this.mail=mail;
        this.direc=direc;
        this.fechaDeIngreso=fechaDeIngreso;
    }

    public Persona() {
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public String getMail() {
        return mail;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }

    public String getDirec() {
        return direc;
    }

    public void setDirec(String direc) {
        this.direc = direc;
    }

    @Override
    public String toString(){
        return "Nombre:" + nombre + "\nApellido:" + apellido + "\nDni:" + dni+ "\nTelefono:" + tel + "\nDireccion: " + direc+"\nMail:"+mail;
    }

    abstract public long antiguedad();

}
