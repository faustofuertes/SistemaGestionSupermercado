package logica.clases.personas;

import logica.clases.facturacion.Remito;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;

public class Cajero extends Usuario implements Serializable{

    private ArrayList<Remito> historialVentasCajero;

    public Cajero(String contrasenia, CargoEmpleado cargo, double sueldo, String nombre, String apellido, String dni, String celular, String mail, String direc, LocalDate fechaDeingreso) {
        super(contrasenia, cargo, sueldo, nombre, apellido, dni, mail,celular, direc,fechaDeingreso);
        this.historialVentasCajero=new ArrayList<>();
    }
    public Cajero(){

    }
    public Cajero(String contrasenia, CargoEmpleado cargo, String nombre, String apellido, String dni, String celular,String mail,String direc,LocalDate fechaDeIngreso) {
        super(contrasenia, cargo, nombre, apellido, dni, celular,mail, direc,fechaDeIngreso);
        this.historialVentasCajero=new ArrayList<>();
    }


    public ArrayList<Remito> getHistorialVentasCajero() {
        return historialVentasCajero;
    }

    public void setHistorialVentasCajero(ArrayList<Remito> historialVentasCajero) {
        this.historialVentasCajero = historialVentasCajero;
    }





}
