package logica.clases.personas;

import java.io.Serializable;

public enum CargoEmpleado implements Serializable {
    Gerente, Cajero, Limpieza, Admin, Repositor;
}
