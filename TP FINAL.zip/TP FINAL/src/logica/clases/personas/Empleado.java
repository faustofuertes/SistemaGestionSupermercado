package logica.clases.personas;


import java.io.Serializable;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Comparator;

public class Empleado extends Persona implements Comparable<Empleado>,Serializable {

    private CargoEmpleado cargo;
    private double sueldo;

    public Empleado(CargoEmpleado cargo, double sueldo, String nombre, String apellido, String dni, String mail, String tel, String direc,LocalDate fechaDeIngreso) {
        super(nombre, apellido, dni, tel, mail, direc,fechaDeIngreso);
        this.cargo = cargo;
        this.sueldo=sueldo;
    }
    public Empleado(){

    }
    public Empleado(CargoEmpleado cargo, String nombre, String apellido, String dni, String mail, String tel, String direc,LocalDate fechaDeIngreso) {
        super(nombre, apellido, dni, tel, mail, direc,fechaDeIngreso);
        this.cargo = cargo;
        this.sueldo=0;
    }

    public CargoEmpleado getCargo() {
        return cargo;
    }

    public void setCargo(CargoEmpleado cargo) {
        this.cargo = cargo;
    }

    public double getSueldo() {
        return sueldo;
    }

    public void setSueldo(double sueldo) {
        this.sueldo = sueldo;
    }

    @Override
    public String toString(){
        return "-------------------------\n"+super.toString()+"\nCargo:"+cargo+"\nSueldo:"+sueldo+"\nfecha De Ingreso"+fechaDeIngreso.toString()+"\n-------------------------\n";
    }


    @Override
    public long antiguedad() {
        return ChronoUnit.YEARS.between(fechaDeIngreso, LocalDate.now());
    }


    public static Comparator<Empleado> comparatorByCargo() {
        return Comparator.comparing(Empleado::getCargo, Comparator.naturalOrder());
    }


    public static Comparator<Empleado> comparatorPorFechaDeIngreso() {
        return Comparator.comparing(empleado -> empleado.fechaDeIngreso);
    }

    @Override
    public int compareTo(Empleado otro){
        return super.getDni().compareTo(otro.getDni());
    }

}
