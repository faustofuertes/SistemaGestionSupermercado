package logica.clases.excepciones;

import java.io.Serializable;

public  class InvalidNumberException extends Exception implements Serializable {
    public InvalidNumberException(String message) {
        super(message);
    }
}