package logica.clases.facturacion;

import java.io.Serializable;
import java.util.Objects;
import java.util.Random;

public class Producto implements Serializable {
    private int id;
    private String desc;
    private int precio;
    private int cant;
    private int stock;

    public Producto(String desc, int precio, int cant) {
        this.id = generateId();
        this.desc = desc;
        this.precio = precio;
        this.cant=cant;
    }


    public Producto(int stock, String desc, int precio) {
        this.id = generateId();
        this.desc = desc;
        this.precio = precio;
        this.stock=stock;
        cant=0;
    }

    private int generateId(){
        Random random = new Random();
        return 1000 + random.nextInt(9000);
    }

    public Producto() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public int getPrecio() {
        return precio;
    }

    public void setPrecio(int precio) {
        this.precio = precio;
    }

    public void setCant(int cant) {
        this.cant = cant;
    }

    public int getCant() {
        return cant;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    @Override
    public String toString() {
        String idStr = String.format("    %-10s", id);
        String descStr = String.format("            %-20s", desc);
        String precioStr = String.format("                 %-10s", precio);

        return idStr + descStr + precioStr;
    }

    public void restaStock(){
        this.stock--;
    }

    public void sumaStock(){
        this.stock++;
    }

    public double calcTotal(){
        return cant * precio;
    }
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Producto producto)) return false;
        return Objects.equals(desc, producto.desc);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(desc);
    }
}
