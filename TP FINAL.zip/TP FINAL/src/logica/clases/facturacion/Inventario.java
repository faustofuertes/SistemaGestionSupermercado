package logica.clases.facturacion;

import java.io.Serializable;
import java.util.*;

public class Inventario implements Serializable {
    private TreeMap<String, ArrayList<Producto>> secciones;//va a contener las seccione de todo los products y adentro el arreglo con los productos de esa SeCCION

    public Inventario() {
        this.secciones = new TreeMap<>();
    }

    public int busquedaProductoEspeciico(Producto producto,String seccion)
    {
        int pos=-1;
        if(this.secciones.containsKey(seccion));
        {
            for (Producto este: this.secciones.get(seccion))
            {
                if(este.getDesc().equals(este.getDesc()) && este.getClass().getName().equals(producto.getClass().getName()))
                {
                    return pos+1;
                }
                pos++;
            }
        }
        return pos;
    }

    public Producto buscaProduConDescYseccion(String desc, String seccion) {
        Producto produBuscado = null;

        ArrayList<Producto> productosEnSeccion = secciones.get(seccion);

        if (productosEnSeccion != null) {
            for (Producto p : productosEnSeccion) {
                if (p.getDesc().equals(desc)) {
                    produBuscado = p;
                    break;
                }
            }
        }
        return produBuscado;
    }

    public boolean disminuyeStock(String seccion, Producto producto, int cant){
        int index = busquedaProductoEspeciico(producto, seccion);
        if (secciones.get(seccion).get(index).getStock() >= cant){
            secciones.get(seccion).get(index).setStock(secciones.get(seccion).get(index).getStock()-cant);
            return true;
        }
        else
            return false;
    }

    public void aumentaStock(String seccion, Producto producto, int cant){
        int index = busquedaProductoEspeciico(producto, seccion);
        secciones.get(seccion).get(index).setStock(secciones.get(seccion).get(index).getStock()+cant);
    }

    public TreeMap<String, ArrayList<Producto>> getSecciones() {
        return secciones;
    }

    public void setSecciones(TreeMap<String, ArrayList<Producto>> secciones) {
        this.secciones = secciones;
    }

    public void agregarProducto(String seccion, Producto producto) {
        if (!this.secciones.containsKey(seccion)) {
            this.secciones.put(seccion, new ArrayList<>());
        }

        // Verificar si ya existe un producto con el mismo ID en la sección
        for (Producto p : this.secciones.get(seccion)) {
            if (p.getId() == producto.getId()) {
                // Si el ID ya existe, incrementar el ID del nuevo producto
                producto.setId(producto.getId() + 1);
            }
        }

        if (!this.secciones.containsKey(seccion)) {
            this.secciones.put(seccion, new ArrayList<>());
        }

        if (!this.secciones.get(seccion).contains(producto)) {
            this.secciones.get(seccion).add(producto);
        }

    }
}

