package logica.clases.facturacion;

import logica.clases.facturacion.Producto;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;

public class Remito implements Serializable {
    private LocalDate fecha;
    private int num;
    private static int numProximo=1;
    private ArrayList<Producto> arrayProdcutos;

    public Remito(LocalDate date, ArrayList<Producto> arrayProdcutos) {
        this.fecha = date;
        this.num = 0;
        this.arrayProdcutos = arrayProdcutos;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }

    public ArrayList<Producto> getArrayProdcutos() {
        return arrayProdcutos;
    }

    public void setArrayProdcutos(ArrayList<Producto> arrayProdcutos) {
        this.arrayProdcutos = arrayProdcutos;
    }

    public void agregarProducto(Producto producto){
        arrayProdcutos.add(producto);
    }

    public int calcTotal(){
        int total=0;
        for(int i=0; i<arrayProdcutos.size(); i++){
            total= total + arrayProdcutos.get(i).getPrecio() * arrayProdcutos.get(i).getCant();
        }
        return total;
    }

}
