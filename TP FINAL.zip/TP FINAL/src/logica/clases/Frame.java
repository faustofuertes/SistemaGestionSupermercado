package logica.clases;


import igu.Admin.PantallaPrincipalAdmin;
import igu.Cajero.PantallaPrincipalCajero;
import igu.Gerente.PantallaPrincipalGerente;
import igu.InicioSesion.PantallaPrincipal;
import logica.clases.personas.Cajero;
import logica.clases.personas.Usuario;

import javax.swing.*;

public class Frame {
    public void ejecutarJframe(Gestora gestora){
        PantallaPrincipal p = new PantallaPrincipal(gestora);

        p.setContentPane(p.panelMain);
        p.setLocation(300, 120);
        p.setTitle("Inicio sesión");
        p.setSize(800, 550);
        p.setVisible(true);
        p.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    }
}
